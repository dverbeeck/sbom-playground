# Bibliography

The following documents are useful references for implementers and users of this document:

[1] *Software Package Data Exchange (SPDX®) Specification Version 1.0* and  1.1, 1.2, 2.0, 2.1, and 2.2; SPDX.dev, <https://spdx.dev/specifications>

[2] *Open Source Initiative (OSI)*; <https://opensource.org/licenses>
